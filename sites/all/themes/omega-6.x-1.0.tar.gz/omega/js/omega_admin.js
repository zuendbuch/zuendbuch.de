$(document).ready(function(){	
	$(function(){
		
	});
	
});
