$Id
##########################################################
##### Omega Theme
##########################################################
Project Page:		http://drupal.org/project/omega
Demo Page:		http://omega.himerus.com
Maintainer(s):		Jake Strawn 
##########################################################
